/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package MODEL;


public class MessagesModel {
    private int msg_id;
    private String email;
    private String messages;

    /**
     * @return the msg_id
     */
    public int getMsg_id() {
        return msg_id;
    }

    /**
     * @param msg_id the msg_id to set
     */
    public void setMsg_id(int msg_id) {
        this.msg_id = msg_id;
    }

    /**
     * @return the email
     */
    public String getEmail() {
        return email;
    }

    /**
     * @param email the email to set
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * @return the messages
     */
    public String getMessages() {
        return messages;
    }

    /**
     * @param messages the messages to set
     */
    public void setMessages(String messages) {
        this.messages = messages;
    }
    
    
}
