/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import DAO.BookingDAO;
import MODEL.BookingModel;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class BookingSservlet extends HttpServlet {



    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int user_id= Integer.parseInt(request.getParameter("user_id"));
        String fullname= request.getParameter("fullname");
        String email= request.getParameter("email");
        SimpleDateFormat formater =  new SimpleDateFormat("yyyy-MM-dd");
        String checkin = request.getParameter("checkin");
        String people= request.getParameter("people");
        int days = Integer.parseInt(request.getParameter("days"));
        int total_price = Integer.parseInt(request.getParameter("total_price"));
        int reservation_id = 0;
        String type = request.getParameter("type");
        
        BookingModel reserevation = new BookingModel(reservation_id,user_id,fullname, email, checkin,people,days,total_price,type);
        BookingDAO dao = new BookingDAO();
        dao.insertData(reserevation);
        
    
        request.setAttribute("data", reserevation);
        
        RequestDispatcher dp =request.getRequestDispatcher("home.jsp");
        dp.forward(request, response);
        
   }


    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
