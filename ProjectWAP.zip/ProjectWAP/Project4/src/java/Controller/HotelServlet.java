/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import DAO.DAO;
import DAO.DBConnection;
import MODEL.LoginModel;
import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.System.out;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class HotelServlet extends HttpServlet {
    static Connection conn;
    static PreparedStatement ps;
    static String sql;

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       String username = request.getParameter("email");
        String password = request.getParameter("password");
        try{
            conn= new DBConnection().setConnection();
             sql = "SELECT * FROM account_list WHERE username=? and password=?";
            ps = conn.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, username);
            ps.setString(2, password);
            
            ResultSet rs = ps.executeQuery();

            if(rs.next()) {
               String s1 = rs.getString("userstatus");
                int user_id = rs.getInt("user_id");
                String fullname = rs.getString("full_name");
                if(s1.equalsIgnoreCase("a")){
                    LoginModel user = new LoginModel(username, password, fullname, user_id);
                    getServletContext().setAttribute("user",user);
                    RequestDispatcher dp =request.getRequestDispatcher("admin.jsp");
                    dp.forward(request, response);
                    
                }
                else{
                     LoginModel user = new LoginModel(username, password, fullname, user_id);
                    getServletContext().setAttribute("user",user);
                    RequestDispatcher dp =request.getRequestDispatcher("home.jsp");
                    dp.forward(request, response);
                }
                
            }
            else{
            response.sendRedirect("error.jsp");
            }

            
        }catch(Exception e){
            System.out.println("Error " + e.getMessage());
            }
    }
    
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
