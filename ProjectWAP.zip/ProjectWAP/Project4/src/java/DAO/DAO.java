/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import MODEL.LoginModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;


public class DAO {
    
    static Connection conn;
    static PreparedStatement ps;
    static String sql;
    
    
    
    public LoginModel loginData(String username, String password, String userstatus){
        LoginModel data=null;
        try{
            conn= new DBConnection().setConnection();
             sql = "SELECT * FROM account_list WHERE username=? and password=?";
            ps = conn.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, data.getUsername());
            ps.setString(2, data.getPassword());
                
            
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
            data.setUsername(rs.getString("username"));
            data.setPassword(rs.getString("password"));
            }

            
        }catch(Exception e){
            System.out.println("Error " + e.getMessage());
            }
        return data;
    }

    

}
