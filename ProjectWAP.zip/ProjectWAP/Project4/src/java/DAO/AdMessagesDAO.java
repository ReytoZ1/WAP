/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import static DAO.AdminDAO.conn;
import MODEL.AdminModel;
import MODEL.MessagesModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


public class AdMessagesDAO {
    static Connection conn;
    static PreparedStatement ps;
    static String sql;
    public List<MessagesModel> selectMessages(){
        List<MessagesModel> list=new ArrayList<MessagesModel>();
        try{
            conn= new DBConnection().setConnection();
             sql = "SELECT * FROM msg_tbl";
            ps = conn.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);
            
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                MessagesModel data = new MessagesModel();
                
                data.setMsg_id(rs.getInt("msg_id"));
                data.setEmail(rs.getString("email"));
                data.setMessages(rs.getString("messages"));
                
                list.add(data);
            }
    }
        catch(Exception e){
            System.out.println("Error " + e.getMessage());
            }
        return list;
}
}
