/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import static DAO.BookingDAO.conn;
import MODEL.AdminModel;
import MODEL.BookingModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


public class AdminDAO {
    static Connection conn;
    static PreparedStatement ps;
    static String sql;
    
    public List<AdminModel> selectData(){
        List<AdminModel> list=new ArrayList<AdminModel>();
        try{
            conn= new DBConnection().setConnection();
             sql = "SELECT * FROM booking_tbl";
            ps = conn.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);
            
            ResultSet rs = ps.executeQuery();
            while(rs.next()){
                AdminModel data = new AdminModel();
                
                data.setReservation_id(rs.getInt("booking_id"));
                data.setUser_id(rs.getInt("user_id"));
                data.setFullname(rs.getString("fullname"));
                data.setEmail(rs.getString("email"));
                data.setCheckin(rs.getString("checkin"));
                data.setPeople(rs.getString("people"));
                data.setDays(rs.getInt("days"));
                data.setTotal_price(rs.getInt("total_price"));
                data.setType(rs.getString("type"));
                
                list.add(data);
            }
    }
        catch(Exception e){
            System.out.println("Error " + e.getMessage());
            }
        return list;
}
}
