/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import MODEL.BookingModel;
import MODEL.RegisterModel;
import java.sql.Connection;
import java.sql.PreparedStatement;


public class BookingDAO {
    static Connection conn;
    static PreparedStatement ps;
    static String sql;
    
    public void insertData(BookingModel data){
        try {
            conn = new DBConnection().setConnection();
            ps = conn.prepareStatement("INSERT INTO booking_tbl(user_id,fullname,email,checkin,people,days,total_price, type) values(?,?,?,?,?,?,?,?)");
            ps.setInt(1, data.getUser_id());
            ps.setString(2, data.getFullname());
            ps.setString(3, data.getEmail());
            ps.setString(4, data.getCheckin());
            ps.setString(5, data.getPeople());
            ps.setInt(6, data.getDays());
             ps.setInt(7, data.getTotal_price());
             ps.setString(8, data.getType());

            ps.executeUpdate();
        } catch (Exception e) {
            System.out.println(e);
        }
    }


}

