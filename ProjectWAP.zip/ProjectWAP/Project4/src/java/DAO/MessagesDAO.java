/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import MODEL.MessagesModel;
import MODEL.RegisterModel;
import java.sql.Connection;
import java.sql.PreparedStatement;


public class MessagesDAO {
    static Connection conn;
    static PreparedStatement ps;
    static String sql;
    
    public void messagesData(MessagesModel data){
        try {
            conn = new DBConnection().setConnection();
            ps = conn.prepareStatement("insert into msg_tbl(email,messages) values(?,?)");
            ps.setString(1, data.getEmail());
            ps.setString(2, data.getMessages());

            ps.executeUpdate();
        } catch (Exception e) {
            System.out.println(e);
        }
}
}
