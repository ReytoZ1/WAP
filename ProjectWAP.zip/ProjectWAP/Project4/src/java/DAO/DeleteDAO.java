/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import static DAO.BookingDAO.conn;
import MODEL.AdminModel;
import MODEL.BookingModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


public class DeleteDAO {
    static Connection conn;
    static PreparedStatement ps;
    static String sql;
    
    public void deleteData(AdminModel model){
        try{
            conn= new DBConnection().setConnection();
             sql = "DELETE FROM booking_tbl where booking_id=?";
            ps = conn.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);
            ps.setInt(1, model.getReservation_id());
            
            ps.executeUpdate();
           
           
    }
        catch(Exception e){
            System.out.println("Error " + e.getMessage());
            }
       
}
}
