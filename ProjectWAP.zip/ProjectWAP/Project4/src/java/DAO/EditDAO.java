/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import static DAO.BookingDAO.conn;
import MODEL.AdminModel;
import MODEL.BookingModel;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;


public class EditDAO {
    static Connection conn;
    static PreparedStatement ps;
    static String sql;
    
    public void updateData(AdminModel model){
        try{
            conn= new DBConnection().setConnection();
             sql = "update booking_tbl set user_id=?,fullname=?,email=?,checkin=?,people=?,days=?,total_price=?,type=? where booking_id=?";
            ps = conn.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS);
            ps.setInt(1, model.getUser_id());
            ps.setString(2, model.getFullname());
            ps.setString(3, model.getEmail());
            ps.setString(4, model.getCheckin());
            ps.setString(5, model.getPeople());
            ps.setInt(6, model.getDays());
            ps.setInt(7, model.getTotal_price());
            ps.setString(8, model.getType());
            ps.setInt(9, model.getReservation_id());
            
            ps.executeUpdate();
           
           
    }
        catch(Exception e){
            System.out.println("Error " + e.getMessage());
            }
       
}
}
